# Contributing

To contribue please checkout/fork the `devel` branch and PR against that repo. Also, we are now standarizing on `ansible 2.9` (which can be found in [EPEL](https://fedoraproject.org/wiki/EPEL) for EL 7 and 8)

Currently, testing is done manually. So please be patient as we get to your PRs.
